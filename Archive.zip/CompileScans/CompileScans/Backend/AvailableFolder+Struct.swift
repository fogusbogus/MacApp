//
//  AvailableFolder+Struct.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import Foundation
import UsefulExtensions

struct AvailableFolder : Codable {
	var name: String
	var imageCount: Int
	var size: AvailableFolderSize
	var mode: FolderMode = .portrait
	
	private enum CodingKeys: String, CodingKey {
		case name, imageCount, size
	}
	
	mutating func setMode(newMode: FolderMode) {
		guard mode != newMode else { return }
		if newMode == .portrait {
			imageCount /= 2
		}
		else {
			imageCount *= 2
		}
	}
}

struct AvailableFolderSize : Codable {
	var isEmpty: Bool
	var width: Int
	var height: Int
}

extension AvailableFolder {
	func description() -> String {
		let year = name.substring(from: 0, length: 4)
		let month = name.substring(from: 4, length: 2)
		let day = name.substring(from: 6, length: 2)
		let time = name.after("_")
		return "\(year)-\(month)-\(day) @ \(time.substring(from: 0, length: 2)):\(time.substring(from: 2, length: 2)):\(time.substring(from: 4, length: 2)) ->  \(imageCount) image\(imageCount > 0 ? "s" : "")"
	}
}


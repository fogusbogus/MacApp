//
//  AvailableFolderWithImages.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import SwiftUI
import Foundation
import UsefulExtensions

enum FolderMode {
	case portrait, brochure
}

class AvailableFolderWithImages : ObservableObject {
	var folder: AvailableFolder
	var images: [Int:CGImage?]
	var selected: Bool = false
	var imagesSelected: [Int:Bool] = [:]
	var saveAs: String = ""
	var date: Date = Date()
	
	private func updateDateFromFolderName() {
		let name = folder.name.keep("1234567890")
		if name.length() == 14 {
			let year  = Int(name.substring(from: 0, length: 4))
			let month = Int(name.substring(from: 4, length: 2))
			let day   = Int(name.substring(from: 6, length: 2))
			let hour  = Int(name.substring(from: 8, length: 2))
			let min   = Int(name.substring(from: 10, length: 2))
			let sec   = Int(name.substring(from: 12, length: 2))
			let components = DateComponents(year: year, month: month, day: day, hour: hour, minute: min, second: sec)
			date = Calendar(identifier: .gregorian).date(from: components) ?? Date()
			saveAs = date.toString("yyyyMMdd-hhmmss")
		}
		
	}
	
	init(folder: AvailableFolder, delegate: AvailableFolderWithImagesDelegate? = nil) {
		self.folder = folder
		
		self.images = [:]
		(0..<self.folder.imageCount).forEach { idx in
			self.images[idx] = nil
			self.imagesSelected[idx] = true
		}
		
		(0..<self.folder.imageCount).forEach { idx in
			SourceData.getImage(folder: self.folder, imageNo: idx) { img in
				DispatchQueue.main.async {
					self.images[idx] = img
					self.imagesSelected[idx] = true
				}
				//delegate?.updateUI()
			}
		}
		updateDateFromFolderName()
		
		if let scan = Scan.find(folder.name) {
			saveAs = scan.saveAs ?? saveAs
			date = scan.itemDate ?? date
		}
	}
}

protocol AvailableFolderWithImagesDelegate {
	func updateUI()
}

extension AvailableFolderWithImages : Hashable {
	static func == (lhs: AvailableFolderWithImages, rhs: AvailableFolderWithImages) -> Bool {
		return lhs.folder.name == rhs.folder.name
	}
	
	func hash(into hasher: inout Hasher) {
		hasher.combine(folder.name)
		hasher.combine(folder.imageCount)
	}
}

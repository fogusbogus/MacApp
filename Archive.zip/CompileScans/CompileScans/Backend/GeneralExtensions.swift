//
//  GeneralExtensions.swift
//  CompileScans
//
//  Created by Matt Hogg on 18/08/2022.
//

import Foundation
import SwiftUI

extension Binding {
	func onChange(_ handler: @escaping (Value) -> Void) -> Binding<Value> {
		return Binding(
			get: { self.wrappedValue },
			set: { selection in
				self.wrappedValue = selection
				handler(selection)
			})
	}
}

extension NSSet {
	func toArray<T>() -> [T] {
		let array = self.map({ $0 as! T})
		return array
	}
}


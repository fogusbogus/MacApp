//
//  SourceData.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import Foundation
import SwiftUI

class SourceData {
	
	static func shell(_ command: String) -> String {
		let task = Process()
		let pipe = Pipe()
		
		task.standardOutput = pipe
		task.standardError = pipe
		task.arguments = ["-c", command]
		task.launchPath = "/bin/zsh"
		task.standardInput = nil
		task.launch()
		
		let data = pipe.fileHandleForReading.readDataToEndOfFile()
		let output = String(data: data, encoding: .utf8)!
		
		return output
	}
	
	static func getServiceIP() -> String {
		let output = shell("arp -a").splitToArray("\n")
		var ips = output.filter { s in
			return s.contains("(") && s.contains(")")
		}.map { s in
			return s.after("(").before(")")
		}.uniqueItems()
		
		var found = ""
		ips.insert("192.168.1.112", at: 0)
		ips.insert("192.168.1.114", at: 0)
		ips.insert("matt-ubuntu.local", at: 0)
		ips.forEach { ip in
			if found.isEmpty {
				let s = "http://\(ip):5000/ScanFile/IsAlive"
				print("Trying \(s)...")
				SyncTask.syncTask(with: URL(string: s), timeoutSeconds: 1) { data, response, error in
					if let siteResponse = response as? HTTPURLResponse {
						print("\(s) - \(siteResponse.statusCode)")
						if siteResponse.statusCode == 200 {
							found = ip
						}
					}
//					if let data = data {
//						if let sData = String(data: data, encoding: .utf8) {
//							print("Service is at \(s)")
//							found = ip
//						}
//					}
				}
			}
		}
		return found
	}
	
	private static var _baseURL : String {
		get {
			if _serviceIP.isEmpty {
				_serviceIP = getServiceIP()
			}
			return "http://\(_serviceIP):5000/ScanFile/"
		}
	}
	private static var _deleteURL : String {
		get {
			if _serviceIP.isEmpty {
				_serviceIP = getServiceIP()
			}
			return "http://\(_serviceIP):5000"
		}
	}
	private static var _serviceIP = ""
	static func getAvailableScanFolders() -> [AvailableFolder] {
		var ret : [AvailableFolder] = []
		let getFoldersUrl = URL(string: "\(_baseURL)GetFolders")!
		SyncTask.syncTask(with: getFoldersUrl, timeoutSeconds: 30) { data, response, error in
			if let data = data {
				if let json = try? JSONDecoder().decode([AvailableFolder].self, from: data)  {
					ret = json
					json.forEach { folder in
						do {
							try Scan.assert(folder: folder, context: PersistenceController.shared.container.viewContext)
						}
						catch ScanError.cannotAssert(let folder) {
							print("Cannot assert the folder named '\(folder.name)'")
						}
						catch ScanError.cannotSave(let folder, let error) {
							print("Cannot save the folder named '\(folder.name)', error: \(error)")
						}
						catch {
							print(error)
						}
					}
				}
			}
		}
		return ret
	}
	
	static func getImageUrl(folder: AvailableFolder, imageNo: Int, thumbnail: Bool = false) -> URL? {
		return URL(string: "\(_baseURL)GetFolderFileStream/\(folder.name)/\(imageNo)/\(thumbnail)")
	}
	
	static func getImage(folder: AvailableFolder, imageNo: Int, completion: @escaping (CGImage) -> Void) {
		do {
			let url = URL(string: "\(_baseURL)GetFolderFile/\(folder.name)/\(imageNo)")!
			URLSession.shared.dataTask(with: url) { data, response, error in
				if let data = data {
					if let actualData = String(data: data, encoding: .utf8) {
						do {
							if let imgData = Data(base64Encoded: actualData) {
								if let imgSrc = CGImageSourceCreateWithData(imgData as CFData, nil) {
									if let img = CGImageSourceCreateImageAtIndex(imgSrc, 0, nil) {
										completion(img)
									}
								}
							}
						}
					}
				}
			}.resume()
		}
	}
	
	static func getImages(folder: AvailableFolder, imageDownloadedNotification: @escaping (Int, Int) -> Void) -> [Data] {
		var images : [Data] = []
		(0..<folder.imageCount).forEach { imgNo in
			
			do {
				let url = URL(string: "\(_baseURL)GetFolderFile/\(folder.name)/\(imgNo)")
				
				SyncTask.syncTask(with: url, timeoutSeconds: 20) { data, response, error in
					if let data = data {
						if let actualData = String(data: data, encoding: .utf8) {
							do {
								images.append(Data(base64Encoded: actualData)!)
								imageDownloadedNotification(imgNo, folder.imageCount)
							}
						}
					}
				}
			}
		}
		return images
	}
	
	static func getImagesForBrochure(folder: AvailableFolder, imageDownloadedNotification: @escaping (Int, Int) -> Void) -> [Data] {
		var images : [Data] = []
		(0..<folder.imageCount*2).forEach { imgNo in
			
			do {
				let url = URL(string: "\(_baseURL)GetFolderFileStream/\(folder.name)/\(imgNo)/false/brochure")
				
				if let file = try? Data(contentsOf: url!) {
					images.append(file)
					imageDownloadedNotification(imgNo + 1, folder.imageCount * 2)
				}
				
				
			}
		}
		return images
	}
	
	static func clearScan(folder: AvailableFolder) {
		if let url = URL(string: "\(_baseURL)ScrubFolder/\(folder.name)") {
			SyncTask.syncTask(with: url, completion: { data, response, error in
				if let error = error {
					print(error)
				}
			})
		}
	}
}

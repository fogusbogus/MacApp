//
//  SyncTask.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import Foundation

class SyncTask {
	static func syncTask(with: URL, completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
		
		var canExit = false
		let task = URLSession.shared.dataTask(with: with) { data, response, error in
			completion(data, response, error)
			canExit = true
		}
		task.resume()
		while(!canExit) {
			
		}
	}
	
	static func syncTask(with: URLRequest, completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
		
		var canExit = false
		let task = URLSession.shared.dataTask(with: with) { data, response, error in
			completion(data, response, error)
			canExit = true
		}
		task.resume()
		while(!canExit) {
			
		}
	}
	
	static func syncTask(with: URL?, timeoutSeconds: Int, completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
		guard let with = with else {
			return
		}
		
		var canExit = false
		let endTS = Date.now.addingTimeInterval(Double(timeoutSeconds))
		let task = URLSession.shared.dataTask(with: with) { data, response, error in
			completion(data, response, error)
			canExit = true
		}
		task.resume()
		while(!canExit) {
			if Date.now > endTS {
				task.cancel()
				canExit = true
			}
		}
	}
	
	static func syncTask(with: URLRequest?, timeoutSeconds: Int, completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
		guard let with = with else {
			return
		}
		
		var canExit = false
		let endTS = Date.now.addingTimeInterval(Double(timeoutSeconds))
		let task = URLSession.shared.uploadTask(with: with, from: with.httpBody) { data, response, error in
			completion(data, response, error)
			canExit = true
		}
		task.resume()
		while(!canExit) {
			if Date.now > endTS {
				task.cancel()
				canExit = true
			}
		}
	}
}

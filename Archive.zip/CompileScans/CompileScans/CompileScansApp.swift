//
//  CompileScansApp.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import SwiftUI

@main
struct CompileScansApp: App {
    let persistenceController = PersistenceController.shared
	let _init = PersistenceController.shared.seedData()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

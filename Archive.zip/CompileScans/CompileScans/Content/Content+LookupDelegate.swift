//
//  Content+LookupDelegate.swift
//  CompileScans
//
//  Created by Matt Hogg on 30/08/2022.
//

import Foundation
import SwiftUI

extension ContentView : Lookup_UI_Delegate {
	
	/// Retrieves the current list of selected items
	/// - Parameter reference: The type
	/// - Returns: When selecting from a list, we don't include these as they're already selected.
	func getCurrentList(reference: String) -> [LookupItem] {
		let context = PersistenceController.shared.container.viewContext
		do {
			let name = currentFolder!.folder.name
			print("Looking up folder \(name)")
			let scan = try Scan.assert(folder: currentFolder!.folder, context: context)
			switch reference {
				case References.recipients:
					if let list = scan?.getRecipients() {
						return list.map { r in
							return LookupItem(desc: r.desc!)
						}
					}
					return []
					
				case References.senders:
					if let list = scan?.getSenders() {
						return list.map { r in
							return LookupItem(desc: r.desc!)
						}
					}
					return []
					
				case References.documentTypes:
					if let list = scan?.getDocumentTypes() {
						return list.map { r in
							return LookupItem(desc: r.desc!)
						}
					}
					return []
					
				case References.otherTags:
					if let list = scan?.getOtherTags() {
						return list.map { r in
							return LookupItem(desc: r.desc!)
						}
					}
					return []
					
				default:
					break
					
			}
			try context.save()
		}
		catch {
			
		}
		return []
	}
	
	/// This is a brand new item, so we need to add it to the store
	/// - Parameters:
	///   - reference: The type
	///   - name: The item description
	func addNew(reference: String, name: String) {
		let context = PersistenceController.shared.container.viewContext
		do {
			let scan = try Scan.assert(folder: currentFolder!.folder, context: context)
			switch reference {
				case References.recipients:
					scan!.addToRecipients(try Recipient.assert(name, context))
					break
				case References.senders:
					scan!.addToSenders(try Sender.assert(name, context))
					break
				case References.documentTypes:
					scan!.addToDocumentTypes(try CorrespondenceType.assert(name, context))
					break
				case References.otherTags:
					scan!.addToTags(try OtherTags.assert(name, context))
					break
				default:
					break
					
			}
			try context.save()
		}
		catch {
			print("ERR: " + error.localizedDescription)
		}
		
	}
	
	/// We need to add the pre-defined item to the scan record
	/// - Parameters:
	///   - reference: The type
	///   - name: The description
	func addPredefined(reference: String, name: String) {
		let context = PersistenceController.shared.container.viewContext
		do {
			let scan = try Scan.assert(folder: currentFolder!.folder, context: context)
			switch reference {
				case References.recipients:
					scan!.addToRecipients(Recipient.find(name, context)!)
					break
				case References.senders:
					scan!.addToSenders(Sender.find(name, context)!)
					break
				case References.documentTypes:
					scan!.addToDocumentTypes(CorrespondenceType.find(name, context)!)
					break
				case References.otherTags:
					scan!.addToTags(OtherTags.find(name, context)!)
					break
				default:
					break
					
			}
			try context.save()
		}
		catch {
			print("ERR: " + error.localizedDescription)
		}
	}
	
	/// Remove the pre-defined item from the scan
	/// - Parameters:
	///   - reference: The type
	///   - name: The description
	func remove(reference: String, name: String) {
		let context = PersistenceController.shared.container.viewContext
		do {
			let scan = try Scan.assert(folder: currentFolder!.folder, context: context)
			switch reference {
				case References.recipients:
					scan!.removeFromRecipients(Recipient.find(name, context)!)
					break
				case References.senders:
					scan!.removeFromSenders(Sender.find(name, context)!)
					break
				case References.documentTypes:
					scan!.removeFromDocumentTypes(CorrespondenceType.find(name, context)!)
					break
				case References.otherTags:
					scan!.removeFromTags(OtherTags.find(name, context)!)
					break
				default:
					break
					
			}
			try context.save()
		}
		catch {
			print("ERR: " + error.localizedDescription)
			
		}
	}
	
	/// Get a list of all the stored items
	/// - Parameter reference: The type
	/// - Returns: The items
	func getAll(reference: String) -> [LookupItem] {
		
		guard let _ = currentFolder?.folder else { return [] }
		//do {
		//let scan = try Scan.assert(folder: folder)
		switch reference {
			case References.recipients:
				return Recipient.getAll(nil).sorted(by: { a, b in
					return a.desc!.lowercased() < b.desc!.lowercased()
				}).map { r in
					return LookupItem(desc: r.desc ?? "")
				}
			case References.senders:
				return Sender.getAll(nil).sorted(by: { a, b in
					return a.desc!.lowercased() < b.desc!.lowercased()
				}).map { r in
					return LookupItem(desc: r.desc ?? "")
				}
			case References.documentTypes:
				return CorrespondenceType.getAll(nil).sorted(by: { a, b in
					return a.desc!.lowercased() < b.desc!.lowercased()
				}).map { r in
					return LookupItem(desc: r.desc ?? "")
				}
			case References.otherTags:
				return OtherTags.getAll(nil).sorted(by: { a, b in
					return a.desc!.lowercased() < b.desc!.lowercased()
				}).map { r in
					return LookupItem(desc: r.desc ?? "")
				}
			default:
				return []
		}
	}
	
	
}

//
//  ContentView+References.swift
//  CompileScans
//
//  Created by Matt Hogg on 28/08/2022.
//

import Foundation

struct References {
	static var recipients = "RECIPIENTS"
	static var senders = "SENDERS"
	static var documentTypes = "DOCS"
	static var otherTags = "TAGS"
}


//
//  ContentView+ScanFolderDelegate.swift
//  CompileScans
//
//  Created by Matt Hogg on 28/08/2022.
//

import Foundation
import SwiftUI
import PDFKit


extension ContentView: ScanFolderOnTapDelegate {
	/// An image has been clicked/tapped, so it would be nice to have a big version of it on the other side of the window. It would also be nice to have some box around the selected image so we know it's selected.
	/// - Parameters:
	///   - image: The scan details
	///   - index: Which image of the scan has been selected
	func imageSelected(image: AvailableFolderWithImages, index: Int) {
		saveRedirects()
		self._image = image.images[index]!
		self.currentFolder = image
		self.currentIndex = index
		self.saveAs = image.saveAs
		self.date = image.date
	}
	
	/// Create a PDF rendering of our selected scan
	/// - Parameter document: The scan details
	func renderPDF(document: AvailableFolderWithImages) {
		
		saveRedirects()
		
		let paths = FileManager.default.homeDirectoryForCurrentUser
		let dataPath = paths.appendingPathComponent("Scanned PDF", isDirectory: true)
		
		do {
			try FileManager.default.createDirectory(at: dataPath, withIntermediateDirectories: true)
		}
		catch {
			print(error)
		}
		
		let scan = Scan.find(document.folder.name)!
		
		let pdf = PDFDocument()
		var idx = 0
		let images = SourceData.getImages(folder: document.folder) { index, count in
			print("Retrieving images")
		}
		
		images.forEach { data in
			do {
				if let imgSrc = CGImageSourceCreateWithData(data as CFData, nil) {
					if let img = CGImageSourceCreateImageAtIndex(imgSrc, 0, nil) {
						let page = PDFPage()
						_ = ImageAnnotation.create(page: page, image: img)
						pdf.insert(page, at: idx)
						idx += 1
					}
				}
			}
		}
		let filename = document.saveAs + ".pdf"
		pdf.write(to: dataPath.appendingPathComponent(filename))
		setTags(scan: scan, path: dataPath.appendingPathComponent(filename))
		scan.conversionDate = Date.now
		scan.destinationFolder = dataPath.appendingPathComponent(filename)
		scan.scanType = "portrait"
		do {
			try scan.managedObjectContext?.save()
		}
		catch {
			
		}
		foldersDownloadRefresh()
	}
	
	func renderPDFBrochure(document: AvailableFolderWithImages) {
		saveRedirects()
		
		let paths = FileManager.default.homeDirectoryForCurrentUser
		let dataPath = paths.appendingPathComponent("Scanned PDF", isDirectory: true)
		
		do {
			try FileManager.default.createDirectory(at: dataPath, withIntermediateDirectories: true)
		}
		catch {
			print(error)
		}
		let scan = Scan.find(document.folder.name)!
		
		let pdf = PDFDocument()
		
		var idx = 0
		let images = SourceData.getImagesForBrochure(folder: document.folder) { index, count in
			print("Retrieved image #\(index) of \(count)")
		}
		
		images.forEach { data in
			do {
				if let imgSrc = CGImageSourceCreateWithData(data as CFData, nil) {
					if let img = CGImageSourceCreateImageAtIndex(imgSrc, 0, nil) {
						let page = PDFPage()
						_ = ImageAnnotation.create(page: page, image: img)
						pdf.insert(page, at: idx)
						idx += 1
					}
				}
			}
		}
		let filename = document.saveAs + ".pdf"
		pdf.write(to: dataPath.appendingPathComponent(filename))
		setTags(scan: scan, path: dataPath.appendingPathComponent(filename))
		scan.conversionDate = Date.now
		scan.destinationFolder = dataPath.appendingPathComponent(filename)
		scan.scanType = "brochure"
		do {
			try scan.managedObjectContext?.save()
		}
		catch {
			
		}
		foldersDownloadRefresh()
	}
	
	func setTags(scan: Scan, path: URL) {
		var myTags: [String] = []
		scan.getRecipients().forEach { r in
			myTags.append(r.desc!)
		}
		scan.getSenders().forEach { s in
			myTags.append(s.desc!)
		}
		scan.getDocumentTypes().forEach { t in
			myTags.append(t.desc!)
		}
		scan.getOtherTags().forEach { t in
			myTags.append(t.desc!)
		}
		do {
			
			try (path as NSURL).setResourceValue(myTags.uniqueItems(), forKey: .tagNamesKey)
			
		}
		catch {
			
		}
	}
	
	func clearScan(document: AvailableFolderWithImages) {
		if currentFolder?.folder.name == document.folder.name {
			currentFolder = nil
			currentIndex = -1
		}
		SourceData.clearScan(folder: document.folder)
	}
	
	func foldersDownloadRefresh() {
		currentFolder = nil
		currentIndex = -1
	}
	
	private func saveRedirects() {
		if let fld = currentFolder {
			fld.saveAs = saveAs
			fld.date = date
			if let scan = Scan.find(fld.folder.name) {
				scan.saveAs = saveAs
				scan.itemDate = date
				do {
					try scan.managedObjectContext?.save()
				}
				catch {
					
				}
			}
		}
	}
	
}

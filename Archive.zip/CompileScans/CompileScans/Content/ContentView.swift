//
//  ContentView.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import SwiftUI
import CoreData
import PDFKit
import Foundation

struct ContentView: View {

	private func qualify(_ name: String) -> String {
		return name.keep("1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM_")
	}
	

	@State internal var currentFolder: AvailableFolderWithImages?
	@State internal var currentIndex: Int = -1
	
	@Environment(\.managedObjectContext) private var viewContext
	
	@FetchRequest(
		sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
		animation: .default)
	private var items: FetchedResults<Item>
	@State internal var _image: CGImage?

	@Environment(\.presentationMode) var presentationMode
	@State var measuring = MeasuringView()
	
	@State var saveAs : String = ""
	@State var date: Date = Date()

	var body: some View {
		NavigationView {
			VStack {
				ScanFolderList(folders: [], delegate: self, measuring: measuring, selectedFolder: self.currentFolder?.folder, selectedIndex: self.currentIndex)
			}
			.navigationTitle("Folders")
			if let _ = currentFolder {
				HStack(alignment: .top) {
					VStack(alignment:.leading) {
						TextField("Save as", text: $saveAs)
						DatePicker("Date", selection: $date)
						Lookup_UI(reference: References.recipients, title: "Recipients", data: [], currentList: getCurrentList(reference: References.recipients), newItem: -1, newItemText: "", delegate: self)
						Lookup_UI(reference: References.senders, title: "Sender(s)", data: [], currentList: getCurrentList(reference: References.senders), newItem: -1, newItemText: "", delegate: self)
						Lookup_UI(reference: References.documentTypes, title: "Kind", data: [], currentList: getCurrentList(reference: References.documentTypes), newItem: -1, newItemText: "", delegate: self)
						Lookup_UI(reference: References.otherTags, title: "Other tags", data: [], currentList: getCurrentList(reference: References.otherTags), newItem: -1, newItemText: "", delegate: self)

					}
				}
				.navigationTitle("Associated Data")
			}
			Group {
				if let img = _image {
					Image(nsImage: NSImage(cgImage: img, size: NSSize(width: img.width, height: img.height)))
						.resizable()
						.scaledToFit()
						
						.border(.secondary, width: 1)
				}
			}
			.navigationTitle("Document")
		}
	}
	

}


struct ContentView_Previews: PreviewProvider {
	
	static var _init = PersistenceController.shared.seedData()
	
	static var previews: some View {
		ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
	}
}


//
//  CorrespondenceType+Assert.swift
//  CompileScans
//
//  Created by Matt Hogg on 24/08/2022.
//

import SwiftUI

extension CorrespondenceType {
	static func find(_ name: String, _ context: NSManagedObjectContext? = nil) -> CorrespondenceType? {
		let context = context ?? PersistenceController.shared.container.viewContext
		let fetcher = NSFetchRequest<CorrespondenceType>(entityName: "CorrespondenceType")
		let predicate = NSPredicate(format: "desc LIKE %@", argumentArray: [name])
		fetcher.predicate = predicate
		do {
			let result = try context.fetch(fetcher)
			return result.first
		}
		catch {
			
		}
		return nil
	}
	
	enum CorrespondenceTypeError : Error {
		case couldNotAssert(name: String, error: Error)
	}
	
	static func assert(_ name: String, _ context: NSManagedObjectContext? = nil) throws -> CorrespondenceType {
		let context = context ?? PersistenceController.shared.container.viewContext
		if let current = find(name, context) {
			return current
		}
		let ret = CorrespondenceType(context: context)
		ret.desc = name
		do {
			try context.save()
		}
		catch {
			throw CorrespondenceTypeError.couldNotAssert(name: name, error: error)
		}
		return ret
	}
}

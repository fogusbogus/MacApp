//
//  OtherTags+Assert.swift
//  CompileScans
//
//  Created by Matt Hogg on 24/08/2022.
//

import Foundation
import SwiftUI

extension OtherTags {
	static func find(_ name: String, _ context: NSManagedObjectContext? = nil) -> OtherTags? {
		let context = context ?? PersistenceController.shared.container.viewContext
		let fetcher = NSFetchRequest<OtherTags>(entityName: "OtherTags")
		let predicate = NSPredicate(format: "desc LIKE %@", argumentArray: [name])
		fetcher.predicate = predicate
		do {
			let result = try context.fetch(fetcher)
			return result.first
		}
		catch {
			
		}
		return nil
	}
	
	enum OtherTagsError : Error {
		case couldNotAssert(name: String, error: Error)
	}
	
	static func assert(_ name: String, _ context: NSManagedObjectContext? = nil) throws -> OtherTags {
		let context = context ?? PersistenceController.shared.container.viewContext
		if let current = find(name, context) {
			return current
		}
		let ret = OtherTags(context: context)
		ret.desc = name
		do {
			try context.save()
		}
		catch {
			throw OtherTagsError.couldNotAssert(name: name, error: error)
		}
		return ret
	}
}

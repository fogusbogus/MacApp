//
//  Recipient+Assert.swift
//  CompileScans
//
//  Created by Matt Hogg on 23/08/2022.
//

import SwiftUI
import Foundation

extension Recipient {
	static func find(_ name: String, _ context: NSManagedObjectContext? = nil) -> Recipient? {
		let context = context ?? PersistenceController.shared.container.viewContext
		let fetcher = NSFetchRequest<Recipient>(entityName: "Recipient")
		let predicate = NSPredicate(format: "desc LIKE %@", argumentArray: [name])
		fetcher.predicate = predicate
		do {
			let result = try context.fetch(fetcher)
			return result.first
		}
		catch {
			
		}
		return nil
	}
	
	enum RecipientError : Error {
		case couldNotAssert(name: String, error: Error)
	}
	
	static func assert(_ name: String, _ context: NSManagedObjectContext? = nil) throws -> Recipient {
		let context = context ?? PersistenceController.shared.container.viewContext
		if let current = find(name, context) {
			return current
		}
		let ret = Recipient(context: context)
		ret.desc = name
		do {
			try context.save()
		}
		catch {
			throw RecipientError.couldNotAssert(name: name, error: error)
		}
		return ret
	}
}

//
//  Scan+Assert.swift
//  CompileScans
//
//  Created by Matt Hogg on 21/08/2022.
//

import Foundation
import CoreData

enum ScanError: Error {
	case cannotAssert(folder: AvailableFolder)
	case cannotSave(folder: AvailableFolder, error: Error)
}


extension Scan {
	
	static func find(_ name: String, _ context: NSManagedObjectContext? = nil) -> Scan? {
		let context = context ?? PersistenceController.shared.container.viewContext
		let fetcher = NSFetchRequest<Scan>(entityName: "Scan")
		let predicate = NSPredicate(format: "folderName LIKE %@", argumentArray: [name])
		fetcher.predicate = predicate
		do {
			let result = try context.fetch(fetcher)
			return result.first
		}
		catch {
			
		}
		return nil
	}
	
	@discardableResult
	static func assert(folder: AvailableFolder, context: NSManagedObjectContext? = nil) throws -> Scan? {
		let context = context ?? PersistenceController.shared.container.viewContext
		
		let fetcher = NSFetchRequest<Scan>(entityName: "Scan")
		let pred = NSPredicate(format: "folderName = %@", argumentArray: [folder.name])
		fetcher.predicate = pred
		do {
			let result = try context.fetch(fetcher)
			if let scan = result.first {
				return scan
			}
			let ret = Scan(context: context)
			ret.folderName = folder.name
			ret.imageCount = Int32(folder.imageCount)
			do {
				try context.save()
			}
			catch {
				throw ScanError.cannotSave(folder: folder, error: error)
			}
			return ret
			
		}
		catch let error as NSError {
			print("\(error)")
		}
		throw ScanError.cannotAssert(folder: folder)
	}
	
	func getRecipients() -> [Recipient] {
		return self.recipients?.map { item in
			return item as! Recipient
		} ?? []
	}
	
	func getSenders() -> [Sender] {
		return self.senders?.map { item in
			return item as! Sender
		} ?? []
	}
	
	func getDocumentTypes() -> [CorrespondenceType] {
		return self.documentTypes?.map { item in
			return item as! CorrespondenceType
		} ?? []
	}
	
	func getOtherTags() -> [OtherTags] {
		return self.tags?.map { item in
			return item as! OtherTags
		} ?? []
	}
}

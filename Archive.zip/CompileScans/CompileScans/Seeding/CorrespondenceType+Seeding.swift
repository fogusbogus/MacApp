//
//  CorrespondenceType+Seeding.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import Foundation
import CoreData

extension Lookup {
	static func seedData<T>(seed: [T], queryProcess: (T) -> Bool, newRecord: (T) -> Void) {
		seed.forEach { item in
			if queryProcess(item) {
				newRecord(item)
			}
		}
	}
	
}

extension CorrespondenceType : SeededData {
	static func getAll(_ context: NSManagedObjectContext?) -> [CorrespondenceType] {
		let context = context.validateContext()
		let fetcher = NSFetchRequest<CorrespondenceType>(entityName: "CorrespondenceType")
		do {
			let result = try context.fetch(fetcher)
			return result
		}
		catch let error as NSError {
			print("\(error)")
		}
		return []
	}
	
	static func seed(_ context: NSManagedObjectContext? = nil) {
		let context = context.validateContext()
		
		let seedData : [String] = [
			"Correspondence", "Summary", "Statement", "Personal", "Appointment", "Loan", "Account", "Meeting", "Finance Agreement", "Fees", "Insurance", "Car", "Household", "Energy Supplier", "Bank", "Assessment", "Service"
		]
		
		var allData = getAll(context)
		self.seedData(seed: seedData) { !allData.hasMatching($0) } newRecord: { item in
			let rec = CorrespondenceType(context: context)
			rec.desc = item
			allData.append(rec)
		}
		do {
			try context.save()
		}
		catch {
			
		}
	}
}

extension Array where Element : Lookup {
	func lookupByName(_ name: String) -> Element? {
		return self.first { item in
			return item.desc!.uppercased() == name.uppercased()
		}
	}
	
	func hasMatching(_ name: String) -> Bool {
		return self.first { item in
			return item.desc!.uppercased() == name.uppercased()
		} != nil
	}
}

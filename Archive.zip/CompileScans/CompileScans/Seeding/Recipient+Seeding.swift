//
//  Recipient+Seeding.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import Foundation
import CoreData

extension Recipient : SeededData {
	static func getAll(_ context: NSManagedObjectContext?) -> [Recipient] {
		let context = context.validateContext()
		let fetcher = NSFetchRequest<Recipient>(entityName: "Recipient")
		do {
			let result = try context.fetch(fetcher)
			return result
		}
		catch let error as NSError {
			print("\(error)")
		}
		return []
	}
	
	static func seed(_ context: NSManagedObjectContext? = nil) {
		let context = context.validateContext()
		
		let seedData : [String] = [
			"Matt", "Laurie", "George", "Penny", "Pooh"
		]
		
		var allData = getAll(context)
		self.seedData(seed: seedData) { !allData.hasMatching($0) } newRecord: { item in
			let rec = Recipient(context: context)
			rec.desc = item
			allData.append(rec)
		}
		do {
			try context.save()
		}
		catch {
			
		}
	}
}

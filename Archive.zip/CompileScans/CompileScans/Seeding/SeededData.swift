//
//  SeededData.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import Foundation
import CoreData

protocol SeededData {
	static func seed(_ context: NSManagedObjectContext?)
	//func getAll<T>(_ context: NSManagedObjectContext?) -> [T]
}


extension Optional where Wrapped : NSManagedObjectContext {
	func validateContext() -> NSManagedObjectContext {
		guard let context = self else {
			return PersistenceController.shared.container.viewContext
		}
		return context
	}
}


extension Lookup {
	static func lookupByName(_ name: String, _ context: NSManagedObjectContext? = nil) -> Self? {
		let context = context ?? PersistenceController.shared.container.viewContext
		let fetcher = NSFetchRequest<Self>(entityName: "\(Self.self)")
		let pred = NSPredicate(format: "desc LIKE %@", argumentArray: [name])
		fetcher.predicate = pred
		do {
			let result = try context.fetch(fetcher)
			return result.first
		}
		catch let error as NSError {
			print("\(error)")
		}
		return nil
	}
}



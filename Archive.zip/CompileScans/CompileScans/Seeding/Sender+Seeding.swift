//
//  Sender+Seeding.swift
//  CompileScans
//
//  Created by Matt Hogg on 16/08/2022.
//

import Foundation
import CoreData

extension Sender : SeededData {
	static func getAll(_ context: NSManagedObjectContext?) -> [Sender] {
		let context = context.validateContext()
		let fetcher = NSFetchRequest<Sender>(entityName: "Sender")
		do {
			let result = try context.fetch(fetcher)
			return result
		}
		catch let error as NSError {
			print("\(error)")
		}
		return []
	}
	
	static func seed(_ context: NSManagedObjectContext? = nil) {
		let context = context.validateContext()
		
		let seedData : [String] = [
			"Santander", "BMW", "Barclays", "Apple", "NHS", "Scottish Widows", "Erle", "Domestic and General", "Royal London", "Raytheon", "River Software", "SGS College", "Neuropathy", "Osteopathy", "Physio", "Let's Talk", "Pain Management", "DWP", "PIP", "Trauma", "Standard Life", "Stroud District Council", "Working Well", "Blue Badge", "SSE", "EHCP", "Child Trust Fund", "RAC", "EE", "DVLA", "Cardiology", "Equiniti", "Clerical Medical", "Royal Mail", "Mental Health", "Police", "Mark Bates, Ltd.", "Social Services", "CareCo", "Motability", "TSB", "DBS", "Tesco Bank", "ESA", "Retinopathy"
		]
		
		var allData = getAll(context)
		self.seedData(seed: seedData) { !allData.hasMatching($0) } newRecord: { item in
			let rec = Sender(context: context)
			rec.desc = item
			allData.append(rec)
		}
		do {
			try context.save()
		}
		catch {
			
		}
	}
}


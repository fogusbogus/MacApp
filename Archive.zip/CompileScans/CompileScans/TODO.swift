//
//  TODO.swift
//  CompileScans
//
//  Created by Matt Hogg on 25/08/2022.
//

import Foundation

/*
 When creating the PDF, need to show it's been rendered. Can do this with the database timestamp that we set when we render
 -- The row should be green if already rendered
 
 The 'Other Tags' aren't being applied to the file tags.
 -- Done
 
 When we re-download the scans we don't clear the image or the tag selectors.
 */

//
//  DownloadFolders+UI.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import SwiftUI

struct DownloadFolders_UI: View {
	
	var delegate: GetFoldersHandler? = nil
	@Environment(\.presentationMode) var presentationMode
	@State var measuring = MeasuringView()

    var body: some View {
		Button {
			if let delegate = delegate {
				delegate.folderListDownloaded(folders: SourceData.getAvailableScanFolders())
			}
		} label: {
			
			Group {
			Text("Download Scan List")
			Image("symbols/searchScans")
				.padding(.leading, 8)
			}
			.accessibilityHint("Get the list of available scans")
		}
		.buttonStyle(.borderedProminent)

    }
}

protocol GetFoldersHandler {
	func folderListDownloaded(folders: [AvailableFolder])
}

struct DownloadFolders_UI_Previews: PreviewProvider {
    static var previews: some View {
        DownloadFolders_UI()
    }
}

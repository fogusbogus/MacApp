//
//  Lookup+UI.swift
//  CompileScans
//
//  Created by Matt Hogg on 21/08/2022.
//

import SwiftUI

struct LookupItem : Hashable {
	
	init(lookup: Lookup) {
		self.desc = lookup.desc
	}
	
	init(desc: String, isNew: Bool = false) {
		self.desc = desc
	}
	
	var desc: String?
	var isNew: Bool = false
}

struct Lookup_UI: View {
	
	var reference: String
	var title: String = "Some lookup"
	@State var data: [Lookup]
	
	@State var currentList: [LookupItem]
	
	@State var newItem : Int
	@State var newItemText: String
	
	@FocusState private var editInFocus: Bool
	
	var delegate: Lookup_UI_Delegate?
	
	func getBits() -> [LookupItem] {
		
		var ret = delegate?.getAll(reference: reference) ?? []
		
		ret.append(LookupItem(desc: "<New Value>", isNew: true))
		editInFocus = true
		return ret
	}
	
	private func validNewItemText() -> Bool {
		let text = newItemText.removeMultipleSpaces().trim()
		return !text.isEmptyOrWhitespace() && !(delegate?.getCurrentList(reference: reference).contains(where: { item in
			return item.desc!.implies(text)
		}))! && !data.contains(where: { item in
			return item.desc!.implies(text)
		})
	}
	var body: some View {
		VStack(alignment: .leading) {
			Text(title)
				.font(.title3)
				.foregroundColor(.cyan)
			ForEach(delegate?.getCurrentList(reference: reference) ?? [], id: \.self) { item in
				HStack {

					Button {
						delegate?.remove(reference: reference, name: item.desc!)
//						currentList.removeAll { lookup in
//							return lookup.desc == item.desc
//						}
					} label: {
						Image(systemName: "minus.circle.fill")
							.renderingMode(.template)
							.foregroundColor(Color.red)

					}
					.buttonStyle(.borderless)
					.padding(.leading, 8)
					

					Text(item.desc ?? "")
				}
			}
			Group {
				let bits = getBits()
				if newItem < 0 {
					Picker("",selection: $newItem.onChange({ newValue in
						print(newValue)
						if newValue == bits.count - 1 {
							//Add new
						}
						else {
//							currentList.append(bits[newValue])
							delegate?.addPredefined(reference: reference, name: bits[newValue].desc!)
							newItem = -1
						}
					})) {
						ForEach(0..<bits.count, id: \.self) { i in
							let item = bits[i]
							if !(delegate?.getCurrentList(reference: reference).contains(obj: item))! {
								Button {
//									currentList.append(LookupItem(desc: item.desc!))
									
								} label: {
									Text(item.desc ?? "")
								}
								.tag(i)
							}
						}
					}
					.onChange(of: newItem) { value in
						print(value)
					}
					.pickerStyle(MenuPickerStyle())
					.padding(.trailing, 8)
				}
				else {
					HStack {
						Button {
							//currentList.append(LookupItem(desc: newItemText))
							delegate?.addNew(reference: reference, name: newItemText)
							newItemText = ""
							newItem = -1
						} label: {
							Image(systemName: "plus.circle.fill")
								.foregroundColor(validNewItemText() ? .green : .gray)
						}
						.disabled(!validNewItemText())
						.buttonStyle(.borderless)
						Button {
							newItemText = ""
							newItem = -1
						} label: {
							Image(systemName: "minus.circle.fill")
								.foregroundColor(.red)
						}
						.buttonStyle(.borderless)
						TextField("Enter new value", text: $newItemText)
							.focused($editInFocus)


					}
					.onAppear(perform: {
						self.editInFocus = true
					})
					.padding([.leading, .trailing], 8)
					
				}
			}
			.frame(maxWidth:200)
			Spacer()
		}
	}
}

protocol Lookup_UI_Delegate {
	func addNew(reference: String, name: String)
	func addPredefined(reference: String, name: String)
	func remove(reference: String, name: String)
	func getAll(reference: String) -> [LookupItem]
	func getCurrentList(reference: String) -> [LookupItem]
}

struct Lookup_UI_Previews: PreviewProvider {
	static var dataProvider = LookupData()
	static var previews: some View {
		Lookup_UI(reference: "PREVIEW", data: [], currentList: [LookupItem(desc: "Something")], newItem: -1, newItemText: "", delegate: dataProvider)
	}
}

class LookupData : Lookup_UI_Delegate {
	func getCurrentList(reference: String) -> [LookupItem] {
		return []
	}
	
	private var data : [LookupItem] = [LookupItem(desc: "Something"), LookupItem(desc: "Another thing"), LookupItem(desc: "Nothing")]
	func remove(reference: String, name: String) {
		
	}
	
	func addNew(reference: String, name: String) {
		data.append(LookupItem(desc: name))
	}
	
	func addPredefined(reference: String, name: String) {
		
	}
	
	func getAll(reference: String) -> [LookupItem] {
		return data
	}
	
	
}

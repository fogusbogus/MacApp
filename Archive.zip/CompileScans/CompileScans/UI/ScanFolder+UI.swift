//
//  ScanFolder+UI.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import SwiftUI

struct ScanFolder_UI: View {
	@State var data: AvailableFolderWithImages
	
	private var imageSizeMult : Double {
		get {
			let m1 = 60.0 / Double(data.folder.size.width)
			let m2 = 100.0 / Double(data.folder.size.height)
			return m1.min(m2)
		}
	}
	
	@Environment(\.presentationMode) var presentationMode
	@State var measuring = MeasuringView()

	var delegate: ScanFolderOnTapDelegate? = nil
	
	var selectedFolder: AvailableFolder? = nil
	var selectedIndex: Int = -1

	func isSelected(folder: AvailableFolder, index: Int) -> Bool {
		guard let selectedFolder = selectedFolder else { return false }
		guard index >= 0 else { return false }
		return folder.name.implies(selectedFolder.name) && index == selectedIndex
	}
	
	private func getBackground() -> Color {
		if let scan = Scan.find(data.folder.name) {
			if let _ = scan.conversionDate {
				return Color("standardColors/alreadyRendered")
			}
		}
		return .clear
	}
	
	var body: some View {
		HStack(alignment: .center) {
			VStack (alignment: .leading) {
				Text(data.folder.description())
				ScrollView(.horizontal, showsIndicators: true) {
					HStack(spacing: 24) {
						ForEach(0..<data.folder.imageCount, id:\.self) { idx in
							VStack {
								AsyncImage(url: SourceData.getImageUrl(folder: data.folder, imageNo: idx, thumbnail: true), content: { image in
									image.resizable()
										.aspectRatio(contentMode: .fit)
										.frame(minWidth:CGFloat(Double(data.folder.size.width) * imageSizeMult), maxHeight: CGFloat(Double(data.folder.size.height) * imageSizeMult))
										.border(.secondary, width: 1)
									
								}, placeholder: {
									ProgressView()
								})
								.padding()
								.border(Color("standardColors/selectedImage"), width: isSelected(folder: data.folder, index: idx) ? 3 : 0)
								.onTapGesture(count: 1) {
									//Load the image to the right
									if data.images[idx] == nil {
										SourceData.getImage(folder: data.folder, imageNo: idx) { image in
											data.images[idx] = image
											delegate?.imageSelected(image: data, index: idx)
										}
									}
									else {
										delegate?.imageSelected(image: data, index: idx)
									}
								}
							}
						}
					}
				}
				.padding(.leading, 24)
			}
			VStack (alignment: .leading) {
				Button {
					delegate?.renderPDF(document: data)
				} label: {
					Text("Render as PDF")
					Image("symbols/pdf")
						.padding(.leading, 8)
				}
				.alignedToWidthOf(measuring, key: "RENDERBUTTONS", alignment: .leading)
				
				Button {
					delegate?.renderPDFBrochure(document: data)
				} label: {
					Text("Render as Brochure PDF")
					Image("symbols/brochure")
						.padding(.leading, 8)
				}
				.alignedToWidthOf(measuring, key: "RENDERBUTTONS", alignment: .leading)
				Button {
					delegate?.clearScan(document: data)
				} label: {
					Group {
					Text("Clear scan")
					Image("symbols/removeCategory")
						.padding(.leading, 8)
					}
					.accessibility(label: Text("Removes the scan from the list. Non-destructive."))
				}
				.alignedToWidthOf(measuring, key: "RENDERBUTTONS", alignment: .leading)
			}
			
		}
		.background(getBackground())
		
	}
}

protocol ScanFolderOnTapDelegate {
	func imageSelected(image: AvailableFolderWithImages, index: Int)
	func renderPDF(document: AvailableFolderWithImages)
	func renderPDFBrochure(document: AvailableFolderWithImages)
	func clearScan(document: AvailableFolderWithImages)
	func foldersDownloadRefresh()
}

struct ScanFolder_UI_Previews: PreviewProvider {
	static var previews: some View {
		ScanFolder_UI(data: AvailableFolderWithImages(folder: AvailableFolder(name: "Temp", imageCount: 4, size: AvailableFolderSize(isEmpty: false, width: 500, height: 400))))
	}
}

//
//  ScanFolderList.swift
//  CompileScans
//
//  Created by Matt Hogg on 17/08/2022.
//

import SwiftUI



struct ScanFolderList: View, GetFoldersHandler, AvailableFolderWithImagesDelegate {
	
	func updateUI() {
		uiUpdate.updated = !uiUpdate.updated
	}
	
	@ObservedObject var uiUpdate = UIUpdater()
		
	func folderListDownloaded(folders: [AvailableFolder]) {
		self.folders = []
		uiUpdate.update()
		if folders.count == 0 {
			status = "No scans found!"
		}
		else {
			status = "Found: \(folders.count)\(folders.count != 1 ? "s" : "")"
		}
		status += " - "
		self.folders = folders.map({ folder in
			return AvailableFolderWithImages(folder: folder, delegate: self)
		})
		uiUpdate.update()
		delegate?.foldersDownloadRefresh()
	}
	
	@State var folders: [AvailableFolderWithImages]
	var delegate : ScanFolderOnTapDelegate? = nil
	@Environment(\.presentationMode) var presentationMode
	@State var measuring = MeasuringView()
	var selectedFolder: AvailableFolder? = nil
	var selectedIndex: Int = -1
	@State var status = ""

    var body: some View {
		VStack(alignment:.leading) {
			HStack {
				Text(status)
				DownloadFolders_UI(delegate: self, measuring: measuring)
			}
			ScrollView(.vertical, showsIndicators: true) {
				VStack(alignment:.leading, spacing: 16) {
					
					ForEach(folders, id:\.self) { folder in
						ScanFolder_UI(data: folder, measuring: measuring, delegate: delegate, selectedFolder: selectedFolder, selectedIndex: selectedIndex)
					}
				}
			}
			
		}
    }
}

struct ScanFolderList_Previews: PreviewProvider {
    static var previews: some View {
		ScanFolderList(folders: [])
    }
}


class UIUpdater : ObservableObject {
	@Published var updated: Bool = false
	
	func update() {
		self.updated = !self.updated
	}
}

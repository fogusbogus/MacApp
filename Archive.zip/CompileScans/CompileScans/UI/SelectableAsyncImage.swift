//
//  SelectableAsyncImage.swift
//  CompileScans
//
//  Created by Matt Hogg on 19/08/2022.
//

import SwiftUI

//struct SelectableAsyncImage: View {
//	var url: URL?
//	var size: CGSize
//	var mult: Double
//
//    var body: some View {
//		AsyncImage(url: url, scale: 1.0, content: { image in
//			image.resizable()
//				.aspectRatio(contentMode: .fit)
//				.frame(minWidth:CGFloat(Double(size.width) * mult), maxHeight: CGFloat(Double(size.height) * mult))
//				.border(Color.secondary, width: 1)
//			.overlay {
//				
//			}
//			
//		})
//    }
//}
//
//struct SelectableAsyncImage_Previews: PreviewProvider {
//    static var previews: some View {
//		SelectableAsyncImage(url: nil) { img in
//
//		} placeholder: {
//			ProgressView()
//		}
//
//    }
//}

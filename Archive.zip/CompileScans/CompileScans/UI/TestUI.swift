//
//  TestUI.swift
//  CompileScans
//
//  Created by Matt Hogg on 25/08/2022.
//

import SwiftUI

struct TestUI: View {
    var body: some View {
		Text("Hello, World!")
		
    }
}

struct TestUI_Previews: PreviewProvider {
    static var previews: some View {
        TestUI()
    }
}

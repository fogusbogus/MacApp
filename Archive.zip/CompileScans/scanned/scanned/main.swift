//
//  main.swift
//  scanned
//
//  Created by Matt Hogg on 11/08/2022.
//

import Foundation
import UsefulExtensions
import PDFKit


func fileOrder(_ url: URL) -> Int {
	let fn = url.pathComponents.last!.keep("1234567890")
	if let i = Int(fn) {
		return i
	}
	return Int.max
}

func scannedDateString(folderUrl: URL) -> String {
	let fn = folderUrl.pathComponents.last!.before("_")
	let year = Int(fn.substring(from: 0, length: 4)) ?? Date.now.year
	let month = Int(fn.substring(from: 4, length: 2)) ?? Date.now.month
	let day = Int(fn.substring(from: 6, length: 2)) ?? Date.now.day
	return "\(String(format: "%04d", year))-\(String(format: "%02d", month))-\(String(format: "%02d", day))"
}

func createPdf(datas: [Data], destination: URL, dict: [String:Any] = [:]) {
	let pdf = PDFDocument()
	pdf.setValuesForKeys(dict)
	var idx = 0
	datas.forEach { data in
		do {
			if let imgSrc = CGImageSourceCreateWithData(data as CFData, nil) {
				if let img = CGImageSourceCreateImageAtIndex(imgSrc, 0, nil) {
					let page = PDFPage()
					_ = ImageAnnotation.create(page: page, image: img)
					pdf.insert(page, at: idx)
					idx += 1
				}
			}
		}
	}
	pdf.write(to: destination)
	/*
	 let pdfData = NSMutableData()
	 UIGraphicsBeginPDFContextToData(pdfData, imageView.bounds, nil)
	 UIGraphicsBeginPDFPage()
	 
	 let pdfContext = UIGraphicsGetCurrentContext()
	 
	 if (pdfContext == nil)
	 {
	 return
	 }
	 
	 imageView.layer.renderInContext(pdfContext!)
	 UIGraphicsEndPDFContext()
	 
	 if let documentDirectories: AnyObject = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first
	 {
	 let documentsFileName = (documentDirectories as! String)  + ("/\myPDFImage.pdf")
	 debugPrint(documentsFileName, terminator: "")
	 pdfData.writeToFile(documentsFileName, atomically: true)
	 }
	 */
}

struct AvailableFolder : Codable {

	var name: String
	var imageCount: Int
	var size: AvailableFolderSize
}

struct AvailableFolderSize : Codable {
	var isEmpty: Bool
	var width: Int
	var height: Int
}

var folders : [AvailableFolder] = []


if true {
	var canExit = false
	let getFoldersUrl = URL(string: "http://192.168.1.112:5000/ScanFile/GetFolders")
	let task = URLSession.shared.dataTask(with: getFoldersUrl!) { data, response, error in
		if let data = data {
			//We have something useful - like a list of folders we can use
			print(data)
			if let json = try? JSONDecoder().decode([AvailableFolder].self, from: data)  {
				folders = json
			}
		}
		canExit = true
	}
	task.resume()
	while(!canExit) {
		
	}
}

let url = "http://192.168.1.112:5000/ScanFile/GetFolderFile/"
folders.forEach { af in
	var images : [Data] = []
	(0..<af.imageCount).forEach { imgNo in
		
		do {
			print("Processing file: \(af.name), image #\(imgNo)")
			let fm = URL(string: url + af.name + "/" + String(describing: imgNo))
			
			var canExit = false
			let task = URLSession.shared.dataTask(with: fm!) { data, response, error in
				if let data = data {
					if let actualData = String(data: data, encoding: .utf8) {
						do {
							images.append(Data(base64Encoded: actualData)!)
						}
					}
				}
				canExit = true
			}
			task.resume()
			while(!canExit) {
				
			}
		}
	}
	let outUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("\(af.name).pdf")
	createPdf(datas: images, destination: outUrl)
	print("Created \(af.name).pdf")
}



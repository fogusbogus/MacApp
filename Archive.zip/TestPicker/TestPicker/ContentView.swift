//
//  ContentView.swift
//  TestPicker
//
//  Created by Matt Hogg on 22/08/2022.
//

import SwiftUI

struct ContentView: View {
	
	@State var coll: [String]
	
	@State var data: [String]
	
	func getSelectable() -> [String] {
		return data.filter { s in
			return !coll.contains(s)
		}
	}
	
	@State var selectedItem: Int = -1
	
	var body: some View {
		VStack {
			
			Picker(selection: $selectedItem.onChange({ newValue in
				print(newValue)
			}), label: EmptyView()) {
				ForEach(0..<getSelectable().count, id:\.self) { i in
					let item = getSelectable()[i]
					Text(item).tag(i)
				}
			}
		}
		
	}
}

struct ContentView_Previews: PreviewProvider {
	
	static var data : [String] = ["First", "Second", "Third"]
	
	static var previews: some View {
		ContentView(coll: [], data: data)
	}
}

extension Binding {
	func onChange(_ handler: @escaping (Value) -> Void) -> Binding<Value> {
		return Binding(
			get: { self.wrappedValue },
			set: { selection in
				self.wrappedValue = selection
				handler(selection)
			})
	}
}

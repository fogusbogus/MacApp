//
//  TestPickerApp.swift
//  TestPicker
//
//  Created by Matt Hogg on 22/08/2022.
//

import SwiftUI

@main
struct TestPickerApp: App {
	
    var body: some Scene {
        WindowGroup {
			ContentView(coll: [
			]
						, data: ["First", "Second", "Third"
						]
, selectedItem: -1)
        }
    }
}
